using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomAnimation : MonoBehaviour
{
    [SerializeField] private string[] _triggerNames;
    private Animator _animator;

    private void Start()
    {
        _animator = GetComponent<Animator>();
        _animator.SetTrigger("Moving");
    }

    public void ChangeAnimation()
    {
        int randomIndex = Random.Range(0, _triggerNames.Length);
        string randomTrigger = _triggerNames[randomIndex];
        _animator.SetTrigger(randomTrigger);
    }
}
